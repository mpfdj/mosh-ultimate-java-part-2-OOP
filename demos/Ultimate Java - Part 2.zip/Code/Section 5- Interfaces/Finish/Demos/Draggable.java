package com.codewithmosh;

public interface Draggable {
  void drag();
}
