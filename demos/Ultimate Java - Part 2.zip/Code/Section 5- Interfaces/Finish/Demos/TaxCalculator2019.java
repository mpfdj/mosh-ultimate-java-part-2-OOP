package com.codewithmosh;

public class TaxCalculator2019 implements TaxCalculator {
  @Override
  public double calculateTax() {
    return 0;
  }
}
