package com.codewithmosh;

public interface UIWidget
        extends Draggable, Resizable {
  void render();
}

