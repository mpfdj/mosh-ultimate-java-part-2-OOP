package com.mytube;

public interface NotificationService {
  void notify(User user);
}
