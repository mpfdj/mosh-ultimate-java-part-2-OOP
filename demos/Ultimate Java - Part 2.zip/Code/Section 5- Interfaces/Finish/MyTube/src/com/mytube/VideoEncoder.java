package com.mytube;

public interface VideoEncoder {
  void encode(Video video);
}
