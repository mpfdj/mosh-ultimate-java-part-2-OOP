package com.mytube;

public interface VideoDatabase {
  void store(Video video);
}
