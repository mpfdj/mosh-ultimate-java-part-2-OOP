package com.codewithmosh;

public class TextBox {
  public String text = "";

  public void setText(String text) {
    this.text = text;
  }

  public void clear() {
    text = "";
  }
}
