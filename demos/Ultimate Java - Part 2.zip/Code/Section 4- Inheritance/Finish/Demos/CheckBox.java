package com.codewithmosh;

public final class CheckBox extends UIControl {
  @Override
  public void render() {
    System.out.println("Render CheckBox");
  }
}
